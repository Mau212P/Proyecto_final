# @babel/plugin-syntax-import-assertions

> Allow parsing of the module assertion attributes in the import statement

See our website [@babel/plugin-syntax-import-assertions](https://babeljs.io/docs/babel-plugin-syntax-import-assertions) for more information.

## Install

Using npm:

```sh
npm install --save-dev @babel/plugin-syntax-import-assertions
```

or using yarn:

```sh
yarn add @babel/plugin-syntax-import-assertions --dev
```
